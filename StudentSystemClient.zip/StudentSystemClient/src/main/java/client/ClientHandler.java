package client;

import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread {

    private final Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)
        ) {
            String message = reader.readLine();
            System.out.println("Received from client: " + message);

            // Here you would connect to ServerHandler logic or DAO
            writer.println("Server received: " + message);

        } catch (IOException e) {
            System.out.println("ClientHandler error: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Error closing socket: " + e.getMessage());
            }
        }
    }
}
