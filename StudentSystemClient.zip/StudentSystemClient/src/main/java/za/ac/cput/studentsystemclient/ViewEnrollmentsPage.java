package za.ac.cput.studentsystemclient;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ViewEnrollmentsPage extends JFrame implements ActionListener {

    private JTextField txtCourseId = new JTextField(12);
    private JButton btnGet = new JButton("Get Enrollments");
    private JTable tblEnrollments = new JTable();
    private DefaultTableModel model = new DefaultTableModel();

    public ViewEnrollmentsPage() {
        super("View Enrollments");
        this.setLayout(new BorderLayout());

        JPanel top = new JPanel();
        top.add(new JLabel("Course ID:"));
        top.add(txtCourseId);
        top.add(btnGet);
        this.add(top, BorderLayout.NORTH);

        model.addColumn("Name");
        model.addColumn("SurName");
        model.addColumn("CourseID");
        model.addColumn("CourseName");
        tblEnrollments.setModel(model);
        this.add(new JScrollPane(tblEnrollments), BorderLayout.CENTER);

        btnGet.addActionListener(this);
        this.setSize(600,400);
        this.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String courseId = txtCourseId.getText().trim();
        if(courseId.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Enter course ID");
            return;
        }
        String response = Client.sendToServer("GETENROLLMENTS:" + courseId);
        model.setRowCount(0); // clear table
        if(response.startsWith("ERROR:")) {
            JOptionPane.showMessageDialog(this,response.substring(6));
        } else if(response.startsWith("EMPTY:")) {
            JOptionPane.showMessageDialog(this,"No enrollments found for this course");
        } else {
            String[] rows = response.split("\\|\\|");
            for(String row : rows) {
                String[] parts = row.split(" - ");
                model.addRow(new Object[]{parts[0].split(" ")[0], parts[0].split(" ")[1], parts[1].split(" ")[0], parts[1].substring(parts[1].indexOf(" ")+1)});
            }
        }
    }
}
