package za.ac.cput.studentsystemclient;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ViewEnrollmentsPage extends JFrame implements ActionListener {

    private JPanel pnlMain = new JPanel();
    private JLabel lblTitle = new JLabel("VIEW ENROLLMENTS PAGE");
    private JTextArea txtDisplay = new JTextArea(10, 50);
    private JScrollPane scrollPane;

    private JMenuBar menuBar = new JMenuBar();
    private JMenu menu = new JMenu("Menu");

    private JMenuItem menuAddStudent = new JMenuItem("Add Student");
    private JMenuItem menuAddCourse = new JMenuItem("Add Course");
    private JMenuItem menuViewEnrollments = new JMenuItem("View Enrollments");
    private JMenuItem menuLogout = new JMenuItem("Logout");

    public ViewEnrollmentsPage() {
        super("Student System - View Enrollments");
        this.setLayout(new BorderLayout());
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        lblTitle.setHorizontalAlignment(JLabel.CENTER);
        lblTitle.setFont(lblTitle.getFont().deriveFont(Font.BOLD, 28f));

        // Configure text area
        txtDisplay.setEditable(false);
        txtDisplay.setBackground(Color.LIGHT_GRAY);
        txtDisplay.setLineWrap(true);
        txtDisplay.setWrapStyleWord(true);
        scrollPane = new JScrollPane(txtDisplay);

        pnlMain.setLayout(new BorderLayout());
        pnlMain.add(lblTitle, BorderLayout.NORTH);
        pnlMain.add(scrollPane, BorderLayout.CENTER);

        menuAddStudent.addActionListener(this);
        menuAddCourse.addActionListener(this);
        menuViewEnrollments.addActionListener(this);
        menuLogout.addActionListener(this);

        menu.add(menuAddStudent);
        menu.add(menuAddCourse);
        menu.add(menuViewEnrollments);
        menu.addSeparator();
        menu.add(menuLogout);
        menuBar.add(menu);
        this.setJMenuBar(menuBar);

        this.add(pnlMain, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == menuAddStudent) {
            this.dispose();
            new AddStudentPage().setVisible(true);
        } else if (source == menuAddCourse) {
            this.dispose();
            new AddCoursePage().setVisible(true);
        } else if (source == menuViewEnrollments) {
            // Already here
        } else if (source == menuLogout) {
            this.dispose();
            new LoginPage().setVisible(true);
        }
    }
}
