package za.ac.cput.studentsystemclient;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import javax.swing.ListSelectionModel;

public class StudentPage extends JFrame implements ActionListener {

    private JPanel pnlPage = new JPanel();
    private JPanel pnlLabel = new JPanel();
    private JPanel pnlChoose = new JPanel();
    private JPanel pnlDisplay = new JPanel();
    private JPanel pnlButton = new JPanel();

    private JLabel lblLogo = new JLabel("STUDENT");

    private JTextField txtDisplay = new JTextField();

    private JTable tblCourse = new JTable();
    private DefaultTableModel modelCourse = new DefaultTableModel();

    private JButton btnEnroll = new JButton("Enroll");
    private JButton btnDisplay = new JButton("Display Enrollments");

    // for now we will use sample student id "1" (server created sample). Later you can pass logged-in id.
    private final String studentId = "1";

    public StudentPage() {
        super("Student System");
        this.setLayout(new GridLayout(1, 1, 5, 5));
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        pnlPage.setLayout(new GridLayout(4, 1, 5, 5));
        pnlPage.add(pnlLabel);
        pnlPage.add(pnlChoose);
        pnlPage.add(pnlDisplay);
        pnlPage.add(pnlButton);

        pnlLabel.setLayout(new GridLayout(1, 1, 5, 5));
        pnlLabel.setBackground(new Color(173, 216, 230));
        lblLogo.setFont(lblLogo.getFont().deriveFont(Font.BOLD, 24f));
        lblLogo.setHorizontalAlignment(JLabel.CENTER);
        pnlLabel.add(lblLogo);

        pnlChoose.setLayout(new GridLayout(1, 1, 5, 5));
        modelCourse.addColumn("Course ID");
        modelCourse.addColumn("Course Name");
        modelCourse.addColumn("Credits");

        tblCourse.setModel(modelCourse);
        tblCourse.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(tblCourse);
        pnlChoose.add(scrollPane);

        pnlDisplay.setLayout(new GridLayout(1, 1, 5, 5));
        pnlDisplay.add(txtDisplay);
        txtDisplay.setEditable(false);
        txtDisplay.setFont(new Font("Arial", Font.PLAIN, 14));
        txtDisplay.setBackground(new Color(245, 245, 245));
        txtDisplay.setBorder(new EmptyBorder(5, 10, 5, 10));

        pnlButton.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnEnroll.setPreferredSize(new java.awt.Dimension(200, 50));
        btnDisplay.setPreferredSize(new java.awt.Dimension(200, 50));

        btnEnroll.setBackground(new Color(100, 149, 237));
        btnEnroll.setForeground(Color.WHITE);
        btnEnroll.setFocusPainted(false);
        btnEnroll.setFont(new Font("SansSerif", Font.BOLD, 16));

        btnDisplay.setBackground(new Color(60, 179, 113));
        btnDisplay.setForeground(Color.WHITE);
        btnDisplay.setFocusPainted(false);
        btnDisplay.setFont(new Font("SansSerif", Font.BOLD, 16));

        pnlButton.add(btnEnroll);
        pnlButton.add(btnDisplay);

        this.add(pnlPage);

        btnEnroll.addActionListener(this);
        btnDisplay.addActionListener(this);

        // load courses from server immediately
        loadCoursesFromServer();
    }

    private void loadCoursesFromServer() {
        modelCourse.setRowCount(0);
        String resp = Client.sendToServer("LISTCOURSES");
        if (resp == null) {
            txtDisplay.setText("ERROR: No response from server.");
            return;
        }
        if (resp.startsWith("EMPTY:")) {
            txtDisplay.setText("No courses available.");
            return;
        }
        if (resp.startsWith("ERROR:")) {
            txtDisplay.setText(resp.substring(6));
            return;
        }
        // resp contains items separated by '||' and each item like "C001 - Intro to Programming"
        String[] items = resp.split("\\|\\|");
        for (String item : items) {
            String[] parts = item.split(" - ", 2);
            String cid = parts[0].trim();
            String cname = parts.length > 1 ? parts[1].trim() : "";
            // credits not available from server, keep blank or 0
            modelCourse.addRow(new Object[]{cid, cname, ""});
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == btnEnroll) {
            int selectedRow = tblCourse.getSelectedRow();
            if (selectedRow != -1) {
                String courseID = tblCourse.getValueAt(selectedRow, 0).toString();
                // ENROLL:studentId,courseId
                String message = "ENROLL:" + studentId + "," + courseID;
                String response = Client.sendToServer(message);
                txtDisplay.setText(response == null ? "No response" : response);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a course first.");
            }
        } else if (src == btnDisplay) {
            // show this student's enrollments
            String resp = Client.sendToServer("GETSTUDENTENROLLMENTS:" + studentId);
            if (resp == null) resp = "ERROR: No response from server.";
            if (resp.startsWith("EMPTY:")) {
                txtDisplay.setText("No enrollments found for you.");
            } else if (resp.startsWith("ERROR:")) {
                txtDisplay.setText(resp.substring(6));
            } else {
                String[] rows = resp.split("\\|\\|");
                StringBuilder out = new StringBuilder();
                for (String r : rows) out.append(r).append("\n");
                txtDisplay.setText(out.toString());
            }
        }
    }
}
