package za.ac.cput.studentsystemclient;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class LoginPage extends JFrame implements ActionListener {

    //Add Panels
    private JPanel pnlSystem = new JPanel();
    private JPanel pnlLabel = new JPanel();
    private JPanel pnlDetails = new JPanel();
    private JPanel pnlButton = new JPanel();

    //Add labels
    private JLabel lblLogo = new JLabel("Login");
    private JLabel lblUsername = new JLabel("Username: ");
    private JLabel lblPassword = new JLabel("Password: ");

    //Add TextFields
    private JTextField txtUsername = new JTextField(15);
    private JPasswordField txtPassword = new JPasswordField(20);

    //Add Buttons
    private JButton btnLogin = new JButton("LOGIN");

    public LoginPage() {
        super("Student System");
        this.setLayout(new GridLayout(1, 1, 5, 5));
        pnlSystem.setLayout(new GridLayout(3, 1, 5, 5));

        pnlSystem.add(pnlLabel);
        pnlSystem.add(pnlDetails);
        pnlSystem.add(pnlButton);

        pnlLabel.setLayout(new GridLayout(1, 1, 5, 5));
        pnlLabel.setBackground(new Color(173, 216, 230));
        pnlLabel.add(lblLogo);
        lblLogo.setFont(lblLogo.getFont().deriveFont(20f));
        lblLogo.setHorizontalAlignment(JLabel.CENTER);

        pnlDetails.setLayout(new GridLayout(2, 2, 5, 5));
        pnlDetails.add(lblUsername);
        pnlDetails.add(txtUsername);
        pnlDetails.add(lblPassword);
        pnlDetails.add(txtPassword);

        pnlButton.setLayout(new GridLayout(1, 1, 5, 5));
        pnlButton.add(btnLogin);
        pnlButton.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
        btnLogin.setPreferredSize(new java.awt.Dimension(100, 50));

        this.add(pnlSystem);

        btnLogin.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password.");
            return;
        }

        String message = "LOGIN:" + username + "," + password;
        String response = Client.sendToServer(message);

        if (response == null) {
            response = "ERROR:No response from server.";
        }

        if (response.startsWith("SUCCESS:")) {
            String role = response.substring(8).trim().toUpperCase();
            JOptionPane.showMessageDialog(this, "Login successful. Role: " + role);

            if (role.equals("ADMIN")) {
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                adminDashboard.setVisible(true);
                this.dispose();
            } else if (role.equals("STUDENT")) {
                StudentPage studentPage = new StudentPage();
                studentPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                studentPage.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Unknown role: " + role);
            }
        } else if (response.startsWith("ERROR:")) {
            JOptionPane.showMessageDialog(this, response.substring(6));
        } else {
            JOptionPane.showMessageDialog(this, "Unexpected response from server: " + response);
        }
    }

}
