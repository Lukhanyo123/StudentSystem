
package com.mycompany.studentsystemserver;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Mvuyi
 */
public class Server {
/**
 * 
 */


    public static void main(String[] args) {
        int port = 5000;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started. Listening on port " + port + "...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Client connected: " + socket.getInetAddress());

                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String received = reader.readLine();

                System.out.println("Received from client: " + received);

                // Respond to client
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                writer.println("Enrollment confirmed for: " + received);

                socket.close(); // Close client socket after handling
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
