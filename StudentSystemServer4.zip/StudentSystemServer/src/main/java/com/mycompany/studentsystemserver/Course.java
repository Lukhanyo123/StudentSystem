
package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class Course {
     private String courseID;
    private String courseName;
    private String courseCredits;

    public Course(String courseID, String courseName, String courseCredits) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.courseCredits = courseCredits;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCredits() {
        return courseCredits;
    }

    public void setCourseCredits(String credits) {
        this.courseCredits = credits;
    }
    
    
}
