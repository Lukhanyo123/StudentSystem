package com.mycompany.studentsystemserver.enrollmentdao;

import com.mycompany.studentsystemserver.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class EnrollmentDAO {
    public boolean enrollStudent(String studentId, String courseId) {
        String sql = "INSERT INTO ENROLLMENT (STUDENT_ID, COURSE_ID) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(studentId));
            ps.setString(2, courseId);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Enrollment error: " + e.getMessage());
            return false;
        }
    }
}
