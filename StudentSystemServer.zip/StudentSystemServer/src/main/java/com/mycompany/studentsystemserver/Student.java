package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class Student {
    
    public String Name;
    public String Surname;
    public String Email;
    public String Password;

    public Student(String Name, String Surname, String Email, String Password) {
        this.Name = Name;
        this.Surname = Surname;
        this.Email = Email;
        this.Password = Password;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    @Override
    public String toString() {
        return "Student{" + "Name=" + Name + ", Surname=" + Surname + ", Email=" + Email + ", Password=" + Password + '}';
    }
    
    
    
}
