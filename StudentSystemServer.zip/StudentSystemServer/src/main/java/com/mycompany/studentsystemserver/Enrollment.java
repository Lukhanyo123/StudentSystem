package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class Enrollment {
    
}
