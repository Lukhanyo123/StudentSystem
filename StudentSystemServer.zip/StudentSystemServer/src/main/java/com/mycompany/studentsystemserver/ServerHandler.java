package com.mycompany.studentsystemserver;

import com.mycompany.studentsystemserver.coursedao.CourseDAO;
import com.mycompany.studentsystemserver.studentdao.StudentDAO;
import com.mycompany.studentsystemserver.userdao.UserDAO;
import com.mycompany.studentsystemserver.enrollmentdao.EnrollmentDAO;
import java.io.*;
import java.net.*;

public class ServerHandler extends Thread {
    private final Socket socket;

    public ServerHandler(Socket socket) {
        this.socket = socket;
    }
    
    

    @Override
    public void run() {
        try (
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
        ) {
            String message = reader.readLine();
            System.out.println("Received: " + message);

            String response = processMessage(message);
            writer.println(response);

        } catch (IOException e) {
            System.out.println("ServerHandler Error: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.out.println("Error closing socket: " + e.getMessage());
            }
        }
    }

    private String processMessage(String msg) {
        if (msg == null || msg.isEmpty()) return "Empty request";

        try {
            // 🧩 Handle adding a new course
            if (msg.startsWith("COURSE:")) {
                String[] parts = msg.substring(7).split(",");
                if (parts.length == 3) {
                    Course course = new Course(parts[0].trim(), parts[1].trim(), Integer.parseInt(parts[2].trim()));
                    CourseDAO dao = new CourseDAO();
                    boolean added = dao.addCourse(course);
                    return added ? "Course added successfully." : "Failed to add course.";
                }
            }

            // 🧩 Handle adding a new student
            else if (msg.startsWith("STUDENT:")) {
                String[] parts = msg.substring(8).split(",");
                if (parts.length == 4) {
                    Student s = new Student(parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim());
                    StudentDAO dao = new StudentDAO();
                    boolean added = dao.addStudent(s);
                    return added ? "Student added successfully." : "Failed to add student.";
                }
            }

            // 🧩 Handle user login
            else if (msg.startsWith("LOGIN:")) {
                String[] parts = msg.substring(6).split(",");
                if (parts.length == 2) {
                    UserDAO dao = new UserDAO();
                    boolean ok = dao.login(parts[0].trim(), parts[1].trim());
                    return ok ? "Login successful." : "Invalid username or password.";
                }
            }

            // 🧩 Handle enrollment
            else if (msg.startsWith("ENROLL:")) {
                String[] parts = msg.substring(7).split(",");
                if (parts.length == 2) {
                    EnrollmentDAO dao = new EnrollmentDAO();
                    boolean ok = dao.enrollStudent(parts[0].trim(), parts[1].trim());
                    return ok ? "Enrollment successful." : "Enrollment failed.";
                }
            }

        } catch (Exception e) {
            return "Error processing request: " + e.getMessage();
        }

        return "Unknown command or invalid format.";
    }
}
