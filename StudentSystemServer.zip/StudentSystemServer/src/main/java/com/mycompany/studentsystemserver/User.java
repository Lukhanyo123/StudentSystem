package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class User {
    
    public String Username;
    public String Password;

    public User(String Username, String Password) {
        this.Username = Username;
        this.Password = Password;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    @Override
    public String toString() {
        return "UserDAO{" + "Username=" + Username + ", Password=" + Password + '}';
    }
    
    
    
}
