package com.mycompany.studentsystemserver.coursedao;

import com.mycompany.studentsystemserver.Course;
import com.mycompany.studentsystemserver.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class CourseDAO {
    public boolean addCourse(Course course) {
        String sql = "INSERT INTO COURSE (COURSE_ID, COURSE_NAME, COURSE_CREDIT) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, course.getCourseID());
            ps.setString(2, course.getCourseName());
            ps.setInt(3, course.getCourseCredit());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error adding course: " + e.getMessage());
            return false;
        }
    }
}
