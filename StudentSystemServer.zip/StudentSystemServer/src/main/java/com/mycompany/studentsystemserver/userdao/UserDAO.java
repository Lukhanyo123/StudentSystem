package com.mycompany.studentsystemserver.userdao;

import com.mycompany.studentsystemserver.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {
    public boolean login(String username, String password) {
        String sql = "SELECT * FROM USER_ACCOUNT WHERE USERNAME=? AND PASSWORD=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            System.out.println("Login error: " + e.getMessage());
            return false;
        }
    }
}
