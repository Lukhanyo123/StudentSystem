package com.mycompany.studentsystemserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

    // Derby network DB URL with create=true to allow initial create
    private static final String URL = "jdbc:derby://localhost:1527/StudentSystem;create=true";
    private static final String USER = "Administrator";
    private static final String PASSWORD = "admin";
    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // load driver optional for modern JDKs but safe
                try {
                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                } catch (ClassNotFoundException ignored) {}

                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Connected to StudentSystem database successfully!");

                
            }
        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
            e.printStackTrace();
        }
        return connection;
    }
}
