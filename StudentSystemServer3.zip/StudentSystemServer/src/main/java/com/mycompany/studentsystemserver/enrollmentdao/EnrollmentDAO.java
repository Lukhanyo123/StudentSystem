package com.mycompany.studentsystemserver.enrollmentdao;

import com.mycompany.studentsystemserver.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {

    public boolean enrollStudent(String studentId, String courseId) {
        String sql = "INSERT INTO ENROLLMENT (STUDENT_ID, COURSE_ID) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentId);
            ps.setString(2, courseId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("enrollStudent error: " + e.getMessage());
            return false;
        }
    }

    // ✅ NEW method: get all students enrolled in a course
    public List<String> getEnrollmentsForCourse(String courseId) {
        List<String> list = new ArrayList<>();
        String sql = """
            SELECT S.NAME, S.SURNAME
            FROM ENROLLMENT E
            JOIN STUDENT S ON E.STUDENT_ID = S.STUDENT_ID
            WHERE E.COURSE_ID = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString("NAME") + " " + rs.getString("SURNAME"));
                }
            }
        } catch (SQLException e) {
            System.out.println("getEnrollmentsForCourse error: " + e.getMessage());
        }
        return list;
    }

    // ✅ NEW method: get all courses a student is enrolled in
    public List<String> getEnrollmentsForStudent(String studentId) {
        List<String> list = new ArrayList<>();
        String sql = """
            SELECT C.COURSE_NAME
            FROM ENROLLMENT E
            JOIN COURSE C ON E.COURSE_ID = C.COURSE_ID
            WHERE E.STUDENT_ID = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString("COURSE_NAME"));
                }
            }
        } catch (SQLException e) {
            System.out.println("getEnrollmentsForStudent error: " + e.getMessage());
        }
        return list;
    }
}
