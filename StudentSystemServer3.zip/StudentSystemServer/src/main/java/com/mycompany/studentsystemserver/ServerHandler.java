package com.mycompany.studentsystemserver;

import com.mycompany.studentsystemserver.coursedao.CourseDAO;
import com.mycompany.studentsystemserver.enrollmentdao.EnrollmentDAO;
import com.mycompany.studentsystemserver.studentdao.StudentDAO;
import com.mycompany.studentsystemserver.userdao.UserDAO;

import java.io.*;
import java.net.Socket;
import java.util.List;

public class ServerHandler extends Thread {
    private final Socket socket;
    public ServerHandler(Socket socket) { this.socket = socket; }

    @Override
    public void run() {
        System.out.println("Handler started for client " + socket.getInetAddress());
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("Received: " + line);
                String response = handleCommand(line.trim());
                writer.println(response);
                // Keep connection alive for multiple commands; client expects single-line responses.
            }

        } catch (IOException e) {
            System.out.println("Connection error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
            System.out.println("Connection closed: " + socket.getInetAddress());
        }
    }

    private String handleCommand(String msg) {
        try {
            if (msg.startsWith("LOGIN:")) {
                // LOGIN:username,password
                String[] parts = msg.substring(6).split(",", 2);
                if (parts.length == 2) {
                    String username = parts[0].trim();
                    String password = parts[1].trim();
                    UserDAO userDAO = new UserDAO();
                    String role = userDAO.authenticate(username, password);
                    if (role != null) {
                        // return SUCCESS:ROLE
                        return "SUCCESS:" + role;
                    } else {
                        return "ERROR:Invalid username or password.";
                    }
                } else {
                    return "ERROR:LOGIN format invalid.";
                }
            }

            if (msg.startsWith("ADDCOURSE:")) {
                // ADDCOURSE:courseId,courseName
                String[] parts = msg.substring(10).split(",", 2);
                if (parts.length == 2) {
                    CourseDAO dao = new CourseDAO();
                    boolean ok = dao.addCourse(parts[0].trim(), parts[1].trim());
                    return ok ? "SUCCESS:Course added." : "ERROR:Failed to add course.";
                } else return "ERROR:ADDCOURSE format invalid.";
            }

            if (msg.startsWith("ADDSTUDENT:")) {
                // ADDSTUDENT:studentId,name,surname
                String[] parts = msg.substring(11).split(",", 3);
                if (parts.length == 3) {
                    StudentDAO dao = new StudentDAO();
                    boolean ok = dao.addStudent(parts[0].trim(), parts[1].trim(), parts[2].trim());
                    return ok ? "SUCCESS:Student added." : "ERROR:Failed to add student.";
                } else return "ERROR:ADDSTUDENT format invalid.";
            }

            if (msg.equalsIgnoreCase("LISTCOURSES")) {
                CourseDAO dao = new CourseDAO();
                List<String> courses = dao.getAllCourses(); // returns list of "id - name"
                if (courses.isEmpty()) return "EMPTY:No courses found.";
                // join with pipe to allow multi-line clarity
                return String.join("||", courses);
            }

            if (msg.startsWith("ENROLL:")) {
                // ENROLL:studentId,courseId
                String[] parts = msg.substring(7).split(",", 2);
                if (parts.length == 2) {
                    EnrollmentDAO dao = new EnrollmentDAO();
                    boolean ok = dao.enrollStudent(parts[0].trim(), parts[1].trim());
                    return ok ? "SUCCESS:Enrollment successful." : "ERROR:Enrollment failed.";
                } else return "ERROR:ENROLL format invalid.";
            }

            if (msg.startsWith("GETENROLLMENTS:")) {
                // GETENROLLMENTS:courseId
                String courseId = msg.substring(15).trim();
                EnrollmentDAO dao = new EnrollmentDAO();
                List<String> list = dao.getEnrollmentsForCourse(courseId); // list of "studentName -> courseName"
                if (list.isEmpty()) return "EMPTY:No enrollments found.";
                return String.join("||", list);
            }

            if (msg.startsWith("GETSTUDENTENROLLMENTS:")) {
                // GETSTUDENTENROLLMENTS:studentId
                String studentId = msg.substring(22).trim();
                EnrollmentDAO dao = new EnrollmentDAO();
                List<String> list = dao.getEnrollmentsForStudent(studentId); // e.g., returns course titles
                if (list.isEmpty()) return "EMPTY:No enrollments for student.";
                return String.join("||", list);
            }

            return "ERROR:Unknown command.";
        } catch (Exception e) {
            e.printStackTrace();
            return "ERROR:Server exception: " + e.getMessage();
        }
    }
}
