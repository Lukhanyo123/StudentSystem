package com.mycompany.studentsystemserver.coursedao;

import com.mycompany.studentsystemserver.Course;
import com.mycompany.studentsystemserver.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    // Existing method: add using object (keep it)
    public boolean addCourse(Course course) {
        String sql = "INSERT INTO COURSE (COURSE_ID, COURSE_NAME) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, course.getCourseId());
            ps.setString(2, course.getCourseName());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("addCourse (Course) error: " + e.getMessage());
            return false;
        }
    }

    // ✅ NEW overloaded version to accept id, name directly
    public boolean addCourse(String courseId, String courseName) {
        return addCourse(new Course(courseId, courseName));
    }

    // ✅ NEW method for ServerHandler: list all courses
    public List<String> getAllCourses() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT COURSE_ID, COURSE_NAME FROM COURSE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(rs.getString("COURSE_ID") + " - " + rs.getString("COURSE_NAME"));
            }
        } catch (SQLException e) {
            System.out.println("getAllCourses error: " + e.getMessage());
        }
        return list;
    }
}
