package com.mycompany.studentsystemserver.studentdao;

import com.mycompany.studentsystemserver.Student;
import com.mycompany.studentsystemserver.DBConnection;
import java.sql.*;

public class StudentDAO {

    public boolean addStudent(Student student) {
        String sql = "INSERT INTO STUDENT (STUDENT_ID, NAME, SURNAME) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, student.getStudentId());
            ps.setString(2, student.getName());
            ps.setString(3, student.getSurname());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("addStudent (Student) error: " + e.getMessage());
            return false;
        }
    }

    // ✅ NEW overloaded version
    public boolean addStudent(String id, String name, String surname) {
        return addStudent(new Student(id, name, surname));
    }
}
