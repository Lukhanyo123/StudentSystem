package com.mycompany.studentsystemserver.userdao;

import com.mycompany.studentsystemserver.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

    /**
     * Authenticates a user.
     * Returns the role (uppercase) if successful, or null if username/password are invalid.
     */
    public String authenticate(String username, String password) {
        String role = null;
        String sql = "SELECT ROLE FROM USERS WHERE USERNAME = ? AND PASSWORD = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username.trim());
            ps.setString(2, password.trim());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    role = rs.getString("ROLE");
                    if (role != null) role = role.trim().toUpperCase();
                    System.out.println("Login SUCCESS for user: '" + username + "', role: " + role);
                } else {
                    System.out.println("Login FAILED for user: '" + username + "'");
                }
            }
        } catch (Exception e) {
            System.out.println("UserDAO authenticate error: " + e.getMessage());
            e.printStackTrace();
        }
        return role;
    }

    /**
     * Adds a user to USERS table.
     * Returns true if inserted, false otherwise.
     */
    public boolean addUser(String username, String password, String role) {
        String sql = "INSERT INTO USERS (USERNAME, PASSWORD, ROLE) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, password.trim());
            ps.setString(3, role.trim().toUpperCase());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("addUser error: " + e.getMessage());
            return false;
        }
    }
}
