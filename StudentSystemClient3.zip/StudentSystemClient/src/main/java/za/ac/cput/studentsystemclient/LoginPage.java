package za.ac.cput.studentsystemclient;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginPage extends JFrame implements ActionListener {

    private JPanel pnlPage = new JPanel();
    private JPanel pnlLabel = new JPanel();
    private JPanel pnlButton = new JPanel();
    private JPanel pnlTextFields = new JPanel();
    private JLabel lblTitle = new JLabel("STUDENT SYSTEM LOGIN");
    private JLabel lblUsername = new JLabel("Username:");
    private JLabel lblPassword = new JLabel("Password:");
    private JTextField txtUsername = new JTextField(20);
    private JPasswordField txtPassword = new JPasswordField(20);
    private JButton btnLogin = new JButton("LOGIN");

    public LoginPage() {
        this.setTitle("Login");
        pnlPage.setLayout(new BorderLayout());
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        pnlPage.add(lblTitle, BorderLayout.NORTH);

        pnlTextFields.setLayout(new GridLayout(2, 2, 10, 10));
        pnlTextFields.add(lblUsername);
        pnlTextFields.add(txtUsername);
        pnlTextFields.add(lblPassword);
        pnlTextFields.add(txtPassword);

        pnlPage.add(pnlTextFields, BorderLayout.CENTER);

        pnlButton.add(btnLogin);
        pnlPage.add(pnlButton, BorderLayout.SOUTH);

        this.add(pnlPage);
        this.pack();
        this.setLocationRelativeTo(null);
        btnLogin.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password.");
            return;
        }

        String message = "LOGIN:" + username + "," + password;
        String response = Client.sendToServer(message);

        if (response == null) response = "ERROR:No response from server.";

        if (response.startsWith("SUCCESS:")) {
            String role = response.substring(8).trim().toUpperCase();
            JOptionPane.showMessageDialog(this, "Login successful. Role: " + role);

            if (role.equals("ADMIN")) {
                AdminDashboard adminDashboard = new AdminDashboard();
                adminDashboard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                adminDashboard.setVisible(true);
                this.dispose();
            } else if (role.equals("STUDENT")) {
                StudentPage studentPage = new StudentPage();
                studentPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                studentPage.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Unknown role: " + role);
            }
        } else if (response.startsWith("ERROR:")) {
            JOptionPane.showMessageDialog(this, response.substring(6));
        } else {
            JOptionPane.showMessageDialog(this, "Unexpected response from server: " + response);
        }
    }

}
