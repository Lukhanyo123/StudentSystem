
package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class Course {
    
    public String CourseID;
    public String CourseName;
    public int CourseCredit;

    public Course(String CourseID, String CourseName, int CourseCredit) {
        this.CourseID = CourseID;
        this.CourseName = CourseName;
        this.CourseCredit = CourseCredit;
    }

    public String getCourseID() {
        return CourseID;
    }

    public void setCourseID(String CourseID) {
        this.CourseID = CourseID;
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String CourseName) {
        this.CourseName = CourseName;
    }

    public int getCourseCredit() {
        return CourseCredit;
    }

    public void setCourseCredit(int CourseCredit) {
        this.CourseCredit = CourseCredit;
    }

}
