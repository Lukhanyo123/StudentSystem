package com.mycompany.studentsystemserver.studentdao;

import com.mycompany.studentsystemserver.DBConnection;
import com.mycompany.studentsystemserver.Student;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class StudentDAO {
    public boolean addStudent(Student s) {
        String sql = "INSERT INTO STUDENT (NAME, SURNAME, EMAIL, USERNAME, PASSWORD) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getName());
            ps.setString(2, s.getSurname());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getUsername());
            ps.setString(5, s.getPassword());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error adding student: " + e.getMessage());
            return false;
        }
    }
}
