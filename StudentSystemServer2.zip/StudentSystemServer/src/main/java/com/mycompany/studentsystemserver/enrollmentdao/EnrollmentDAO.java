package com.mycompany.studentsystemserver.enrollmentdao;

import com.mycompany.studentsystemserver.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {
    public boolean enrollStudent(String studentId, String courseId) {
        String sql = "INSERT INTO ENROLLMENT (STUDENT_ID, COURSE_ID) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setString(2, courseId);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Enrollment error: " + e.getMessage());
            return false;
        }
    }

    public List<String> getEnrollments() {
        List<String> list = new ArrayList<>();
        String sql = "SELECT S.NAME, S.SURNAME, C.COURSE_NAME FROM ENROLLMENT E " +
                     "JOIN STUDENT S ON E.STUDENT_ID = S.USERNAME " +
                     "JOIN COURSE C ON E.COURSE_ID = C.COURSE_ID";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String student = rs.getString("NAME") + " " + rs.getString("SURNAME");
                String course = rs.getString("COURSE_NAME");
                list.add(student + " -> " + course);
            }
        } catch (Exception e) {
            System.out.println("Error fetching enrollments: " + e.getMessage());
        }
        return list;
    }
}
