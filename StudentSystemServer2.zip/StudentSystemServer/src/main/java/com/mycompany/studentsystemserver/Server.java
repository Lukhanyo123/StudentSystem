package com.mycompany.studentsystemserver;

import java.io.*;
import java.net.*;


public class Server {
    public static void main(String[] args) {
        int port = 1234;
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server started on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());
                new ServerHandler(clientSocket).start(); // ✅ multi-threaded
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
