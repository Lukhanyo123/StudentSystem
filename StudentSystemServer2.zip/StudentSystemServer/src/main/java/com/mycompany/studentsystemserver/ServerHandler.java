package com.mycompany.studentsystemserver;

import com.mycompany.studentsystemserver.enrollmentdao.EnrollmentDAO;
import java.io.*;
import java.net.*;

public class ServerHandler extends Thread {
    private final Socket socket;
    public ServerHandler(Socket socket) { this.socket = socket; }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

            String message = reader.readLine();
            System.out.println("Received: " + message);

            String response = processMessage(message);
            writer.println(response);

        } catch (IOException e) {
            System.out.println("ServerHandler Error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException e) { }
        }
    }

    private String processMessage(String msg) {
        if (msg == null || msg.isEmpty()) return "Empty request";

        try {
            if (msg.startsWith("ENROLL:")) {
                String[] parts = msg.substring(7).split(",");
                if (parts.length == 2) {
                    EnrollmentDAO dao = new EnrollmentDAO();
                    boolean ok = dao.enrollStudent(parts[0].trim(), parts[1].trim());
                    return ok ? "Enrollment successful." : "Enrollment failed.";
                }
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return "Unknown command.";
    }
}
