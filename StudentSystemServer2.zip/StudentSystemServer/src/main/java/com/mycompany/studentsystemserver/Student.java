package com.mycompany.studentsystemserver;

/**
 *
 * @author 222830646
 */
public class Student {
    
    private String Name;
    private String Surname;
    private String Email;
    private String Username;
    private String Password;

    public Student(String Name, String Surname, String Email, String Username, String Password) {
        this.Name = Name;
        this.Surname = Surname;
        this.Email = Email;
        this.Username = Username;
        this.Password = Password;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
  
}
   